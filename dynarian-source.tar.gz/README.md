Development moved to https://gitlab.com/blacknet-ninja

https://dynarian.org/ aims to continue on DYNARIAN chain.
